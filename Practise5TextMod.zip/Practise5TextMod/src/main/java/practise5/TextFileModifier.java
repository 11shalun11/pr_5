package practise5;

import java.io.*;

public class TextFileModifier {
    public static void main(String[] args) {
        System.out.println("РИБО-01-21, Практическая работа №5, Вариант 2, Шалунова А.С.");
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Введите путь к исходному файлу: ");
            String filePath = reader.readLine();


            BufferedReader fileReader = new BufferedReader(new FileReader(filePath));


            File outputFile = new File("modified_" + filePath);
            if(!outputFile.exists()){
                outputFile.createNewFile();
            }


            FileWriter fileWriter = new FileWriter(outputFile);

            String line;
            while((line = fileReader.readLine()) != null){
                String reversedLine = new StringBuilder(line).reverse().toString();
                fileWriter.write(reversedLine + "\n");
            }

            reader.close();
            fileReader.close();
            fileWriter.close();

            System.out.println("Файл успешно изменен");

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка при обработке файла");
        }
    }

}

